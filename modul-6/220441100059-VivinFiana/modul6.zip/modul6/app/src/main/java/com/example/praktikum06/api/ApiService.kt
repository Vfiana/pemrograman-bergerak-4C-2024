package com.example.praktikum06.api

import retrofit2.Call
import retrofit2.http.GET
import com.example.praktikum06.model.PlayerResponse

//mendefinisikan metode yang akan memanggil endpoint API
interface ApiService {

//    anotasi yg digunakan pada library retrofit untuk membangun client API
    @GET("tugas")
    fun getPlayers(): Call<PlayerResponse>
}
