package com.example.praktikum06.adapter

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.example.praktikum06.R
import com.example.praktikum06.model.Player
import com.google.android.material.imageview.ShapeableImageView

//adapter untuk RecyclerView yang menampilkan daftar pemain
class PlayerAdapterRetrofit(
    private val playerList: List<Player>,
    private val onItemClickCallback: OnItemClickCallback
) : RecyclerView.Adapter<PlayerAdapterRetrofit.PlayerViewHolder>() {

//    antramuka item on klik
    interface OnItemClickCallback {
        fun onItemClicked(data: Player)
    }

//mendefinisikan variabel yg akan menampung refernsi ke view yg ada di item player
    inner class PlayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val playerName: TextView = itemView.findViewById(R.id.txt_nama)
        val playerPosition: TextView = itemView.findViewById(R.id.txt_position)
        val playerGa: TextView = itemView.findViewById(R.id.txt_ga)
        val playerNumber: TextView = itemView.findViewById(R.id.txt_number)
        val playerRating: TextView = itemView.findViewById(R.id.txt_rating)
        val playerClubLogo: ShapeableImageView = itemView.findViewById(R.id.img_club)
        val playerImage: ImageView = itemView.findViewById(R.id.img_player)
        val backgroundContainer: ConstraintLayout = itemView.findViewById(R.id.img_bg)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlayerViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_player, parent, false)
        return PlayerViewHolder(view)
    }

//    method yg dipanggil oleh RecyclerView untuk mengisi data ke dalam view holder pada posisi tertentu
    override fun onBindViewHolder(holder: PlayerViewHolder, position: Int) {
        val data = playerList[position]
        holder.playerName.text = data.name
        holder.playerPosition.text = data.position
        holder.playerGa.text = data.ga
        holder.playerNumber.text = "#"+data.number.toString()
        holder.playerRating.text = data.rating.toString()

//    untuk memuat gambar dari URL dan menampilkannya ke dalam ImageView dan ConstraintLayout
//    pada RecyclerView dengan library Glide
        Glide.with(holder.playerClubLogo.context).load(data.clubLogo).into(holder.playerClubLogo)
        Glide.with(holder.playerImage.context).load(data.playerImage).into(holder.playerImage)
        Glide.with(holder.backgroundContainer.context)
            .load(data.backgroundCard)
            .into(object : CustomTarget<Drawable>(){
                override fun onResourceReady(
                    resource: Drawable,
                    transition: Transition<in Drawable>?
                ) {
                    holder.backgroundContainer.background = resource
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    TODO("Not yet implemented")
                }
            })

//untuk menangani aksi klik pada item player di RecyclerView
        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(playerList[holder.absoluteAdapterPosition]) }
    }

//untuk menentukan jumlah item yang akan ditampilkan di dalam RecyclerView
    override fun getItemCount(): Int = playerList.size
}
